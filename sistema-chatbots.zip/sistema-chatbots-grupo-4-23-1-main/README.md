[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/raIOteMi)
# ine-5404-sistema-chatbot-template

Template (v0) do Sistema Chatbot - atividade síncrona - INE5404

Veja abaixo um exemplo de funcionamento do sistema:

![image](https://user-images.githubusercontent.com/17619917/109540740-a6b2ef80-7aa1-11eb-8b59-8e79e56d5a68.png)

A partir do diagrama de classes fornecido e usando a estrutura de arquivos deste repositorio:

1) Realizar a implementação do sistema com ao menos dois bots de personalidades diferentes
2) Fornecer as implementações de bot a outros grupos e tentar integrar outras implementações de bot no seu sistema
